// Vertex shader program
const vsSource = `
    attribute vec2 aVertexPosition;
    void main(void) {
        gl_Position = vec4(aVertexPosition, 0.0, 1.0);
    }
`;

// Fragment shader program
const fsSource = `
    precision mediump float;
    uniform vec4 uColor;
    void main(void) {
        gl_FragColor = uColor;
    }
`;

function initWebGL() {
    const canvas = document.getElementById('glCanvas');
    const gl = canvas.getContext('webgl');

    if (!gl) {
        alert('Não foi possível inicializar o WebGL. Seu navegador ou máquina pode não suportá-lo.');
        return null;
    }

    const shaderProgram = initShaderProgram(gl, vsSource, fsSource);

    const programInfo = {
        program: shaderProgram,
        attribLocations: {
            vertexPosition: gl.getAttribLocation(shaderProgram, 'aVertexPosition'),
        },
        uniformLocations: {
            color: gl.getUniformLocation(shaderProgram, 'uColor'),
        },
    };

    const positionBuffer = gl.createBuffer();

    return { gl, programInfo, positionBuffer };
}

function initShaderProgram(gl, vsSource, fsSource) {
    const vertexShader = loadShader(gl, gl.VERTEX_SHADER, vsSource);
    const fragmentShader = loadShader(gl, gl.FRAGMENT_SHADER, fsSource);

    const shaderProgram = gl.createProgram();
    gl.attachShader(shaderProgram, vertexShader);
    gl.attachShader(shaderProgram, fragmentShader);
    gl.linkProgram(shaderProgram);

    if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
        alert('Não foi possível inicializar o shader: ' + gl.getProgramInfoLog(shaderProgram));
        return null;
    }

    return shaderProgram;
}

function loadShader(gl, type, source) {
    const shader = gl.createShader(type);

    gl.shaderSource(shader, source);

    gl.compileShader(shader);

    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        alert('Erro ao compilar o shader: ' + gl.getShaderInfoLog(shader));
        gl.deleteShader(shader);
        return null;
    }

    return shader;
}

function drawClown(gl, programInfo, positionBuffer) {
    gl.clearColor(0.9, 0.9, 0.9, 1.0); 
    gl.clear(gl.COLOR_BUFFER_BIT);

    gl.useProgram(programInfo.program);
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);

    gl.enableVertexAttribArray(programInfo.attribLocations.vertexPosition);
    gl.vertexAttribPointer(
        programInfo.attribLocations.vertexPosition,
        2,        
        gl.FLOAT, 
        false,    
        0,        
        0         
    );

    const segments = 50;

    // Desenha a cabeça
    drawCircle(gl, programInfo, 0, 0, 0.3, [1, 0.8, 0.6, 1], segments);

    // Desenha o cabelo
    const hairColor = [0, 1, 0, 1]; 
    const hairSegments = 5;
    const hairLength = 0.1;
    const hairRadius = 0.3; 

    for (let i = 0; i < hairSegments; i++) {
        const angle = (i / hairSegments) * Math.PI;
        const x1 = hairRadius * Math.cos(angle);
        const y1 = hairRadius * Math.sin(angle);

        const x2 = hairRadius * Math.cos(angle + (Math.PI / hairSegments));
        const y2 = hairRadius * Math.sin(angle + (Math.PI / hairSegments));

        const xTip = (hairRadius + hairLength) * Math.cos(angle + (Math.PI / (2 * hairSegments)));
        const yTip = (hairRadius + hairLength) * Math.sin(angle + (Math.PI / (2 * hairSegments)));

        drawTriangle(gl, programInfo, [
            x1, y1,
            x2, y2,
            xTip, yTip
        ], hairColor);
    }

    // Desenha o nariz
    drawCircle(gl, programInfo, 0, 0, 0.05, [1, 0, 0, 1], segments);

    // Desenha os olhos
    const eyeRadius = 0.03;
    const eyeColor = [0, 0, 0, 1]; 

    // Posição dos olhos
    const leftEyeX = -0.1;
    const leftEyeY = 0.1;
    const rightEyeX = 0.1;
    const rightEyeY = 0.1;

    drawCircle(gl, programInfo, leftEyeX, leftEyeY, eyeRadius, eyeColor, segments);

    drawCircle(gl, programInfo, rightEyeX, rightEyeY, eyeRadius, eyeColor, segments);

    const blushRadius = 0.05;
    const blushColor = [1, 0, 0, 1]; 

    const leftBlushX = -0.15;
    const leftBlushY = -0.05;

    const rightBlushX = 0.15;
    const rightBlushY = -0.05;

    // Desenha o blush
    drawCircle(gl, programInfo, leftBlushX, leftBlushY, blushRadius, blushColor, segments);
    drawCircle(gl, programInfo, rightBlushX, rightBlushY, blushRadius, blushColor, segments);

    // Desenha a boca
    drawRectangle(gl, programInfo, -0.05, -0.13, 0.1, 0.03, [1, 0, 0, 1]);

    // Desenha o chapéu
    drawTriangle(gl, programInfo, [
        -0.15, 0.3,       // Ponto esquerdo
        0.15, 0.3,        // Ponto direito
        0, 0.6           // Ponto superior
    ], [0, 0, 1, 1]);

    // Bolinha do Chapeu
    const hatBallRadius = 0.06;
    const hatBallColor = [1, 0, 0, 1];

    drawCircle(gl, programInfo, 0, 0.6, hatBallRadius, hatBallColor, segments);

}

function drawCircle(gl, programInfo, centerX, centerY, radius, color, segments) {
    const vertices = [];
    vertices.push(centerX, centerY);
    for (let i = 0; i <= segments; i++) {
        const theta = (i / segments) * 2 * Math.PI;
        vertices.push(
            centerX + radius * Math.cos(theta),
            centerY + radius * Math.sin(theta)
        );
    }

    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    gl.uniform4fv(programInfo.uniformLocations.color, color);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, segments + 2);
}

function drawRectangle(gl, programInfo, x, y, width, height, color) {
    const vertices = [
        x, y,
        x + width, y,
        x + width, y + height,
        x, y + height,
    ];

    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    gl.uniform4fv(programInfo.uniformLocations.color, color);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);
}

function drawTriangle(gl, programInfo, vertices, color) {
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    gl.uniform4fv(programInfo.uniformLocations.color, color);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
}

(function main() {
    const { gl, programInfo, positionBuffer } = initWebGL();
    if (gl && programInfo && positionBuffer) {
        drawClown(gl, programInfo, positionBuffer);
    }
})();
