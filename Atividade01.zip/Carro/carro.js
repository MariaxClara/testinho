// Vertex shader program
const vsSource = `
    attribute vec2 aVertexPosition;
    void main(void) {
        gl_Position = vec4(aVertexPosition, 0.0, 1.0);
    }
`;

// Fragment shader program
const fsSource = `
    precision mediump float;
    uniform vec4 uColor;
    void main(void) {
        gl_FragColor = uColor;
    }
`;

function initWebGL() {
    const canvas = document.getElementById('glCanvas');
    const gl = canvas.getContext('webgl');

    if (!gl) {
        alert('Não foi possível inicializar o WebGL. Seu navegador ou máquina pode não suportá-lo.');
        return null;
    }

    const shaderProgram = initShaderProgram(gl, vsSource, fsSource);

    const programInfo = {
        program: shaderProgram,
        attribLocations: {
            vertexPosition: gl.getAttribLocation(shaderProgram, 'aVertexPosition'),
        },
        uniformLocations: {
            color: gl.getUniformLocation(shaderProgram, 'uColor'),
        },
    };

    const positionBuffer = gl.createBuffer();

    return { gl, programInfo, positionBuffer };
}

function initShaderProgram(gl, vsSource, fsSource) {
    const vertexShader = loadShader(gl, gl.VERTEX_SHADER, vsSource);
    const fragmentShader = loadShader(gl, gl.FRAGMENT_SHADER, fsSource);

    const shaderProgram = gl.createProgram();
    gl.attachShader(shaderProgram, vertexShader);
    gl.attachShader(shaderProgram, fragmentShader);
    gl.linkProgram(shaderProgram);

    if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
        alert('Não foi possível inicializar o shader: ' + gl.getProgramInfoLog(shaderProgram));
        return null;
    }

    return shaderProgram;
}

function loadShader(gl, type, source) {
    const shader = gl.createShader(type);

    gl.shaderSource(shader, source);

    gl.compileShader(shader);

    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        alert('Erro ao compilar o shader: ' + gl.getShaderInfoLog(shader));
        gl.deleteShader(shader);
        return null;
    }

    return shader;
}

function drawCar(gl, programInfo, positionBuffer) {
    gl.clearColor(0.9, 0.9, 0.2, 1.0); 
    gl.clear(gl.COLOR_BUFFER_BIT);

    gl.useProgram(programInfo.program);
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);

    gl.enableVertexAttribArray(programInfo.attribLocations.vertexPosition);
    gl.vertexAttribPointer(
        programInfo.attribLocations.vertexPosition,
        2,        
        gl.FLOAT, 
        false,    
        0,        
        0         
    );

    const segments = 50;

    // Desenha o corpo do carro
    const carBodyColor = [1, 0, 0.6, 1];
    const carBodyX = -0.5;
    const carBodyY = -0.2;
    const carBodyWidth = 1.2;
    const carBodyHeight = 0.3;

    drawRectangle(gl, programInfo, carBodyX, carBodyY, carBodyWidth, carBodyHeight, carBodyColor);

    // Desenha o teto do carro
    const carTopColor = [1, 0, 0.6, 1];
    const carTopX = -0.2;
    const carTopY = 0.08;
    const carTopWidth = 0.6;
    const carTopHeight = 0.2;

    drawRectangle(gl, programInfo, carTopX, carTopY, carTopWidth, carTopHeight, carTopColor);

    // Desenha as janelas
    const windowColor = [0.7, 0.9, 1, 1]; 
    const windowX = carTopX + 0.4;
    const windowY = carTopY + 0.2;
    const windowWidth = carTopWidth - 0.4;
    const windowHeight = carTopHeight - 0.38;

    drawRectangle(gl, programInfo, windowX, windowY, windowWidth, windowHeight, windowColor);

    //Desenha triangulo do topo 
    const trianguleColor = [1, 0, 0.6, 1];
    const trianguleX = carTopX - 0.25;
    const trianguleY = carTopY + 0.001;
    const trianguleWidth = 0.25;
    const trianguleHeight = 0.2;
    
    drawTriangule(gl, programInfo, trianguleX, trianguleY, trianguleWidth, trianguleHeight, trianguleColor);

    //Desenha a maçaneta
    const handleColor = [0, 0, 0, 1]; 
    const handleX = carTopX + 0.17;
    const handleY = carTopY - 0.1;
    const handleWidth = 0.1;
    const handleHeight = 0.02;


    drawRectangle(gl, programInfo, handleX, handleY, handleWidth, handleHeight, handleColor);
    

    // Desenha as rodas
    const wheelColor = [0, 0, 0, 1];
    const wheelRadius = 0.12;

    // Roda esquerda
    const leftWheelX = carBodyX + 0.2;
    const wheelY = carBodyY - wheelRadius + 0.1;


    drawCircle(gl, programInfo, leftWheelX, wheelY, wheelRadius, wheelColor, segments);
    const tireRadius = 0.05
    drawCircle(gl, programInfo, leftWheelX, wheelY, tireRadius, [1, 0, 0, 0], segments);

    // Roda direita
    const rightWheelX = carBodyX + carBodyWidth - 0.2;

    drawCircle(gl, programInfo, rightWheelX, wheelY, wheelRadius, wheelColor, segments);
    drawCircle(gl, programInfo, rightWheelX, wheelY, tireRadius, [1, 0, 0, 0], segments);

    // Desenha os faróis
    const headlightColor = [1, 1, 0, 1]; 
    const headlightRadius = 0.03;
    
    // Farol direito
    const headlightY = carBodyY + 0.1;
    const rightHeadlightX = carBodyX + carBodyWidth - 0.05;

    drawCircle(gl, programInfo, rightHeadlightX, headlightY, headlightRadius, headlightColor, segments);
}

function drawCircle(gl, programInfo, centerX, centerY, radius, color, segments) {
    const vertices = [];
    vertices.push(centerX, centerY);
    for (let i = 0; i <= segments; i++) {
        const theta = (i / segments) * 2 * Math.PI;
        vertices.push(
            centerX + radius * Math.cos(theta),
            centerY + radius * Math.sin(theta)
        );
    }

    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    gl.uniform4fv(programInfo.uniformLocations.color, color);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, segments + 2);
}

function drawRectangle(gl, programInfo, x, y, width, height, color) {
    const vertices = [
        x, y,
        x + width, y,
        x + width, y + height,
        x, y + height,
    ];

    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    gl.uniform4fv(programInfo.uniformLocations.color, color);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);
}


 function drawTriangule(gl, programInfo, x, y, width, height, color) {
    const vertices = [
        x, y,
        x + width, y,
        x + width, y + height,
    ];

    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    gl.uniform4fv(programInfo.uniformLocations.color, color);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
}


(function main() {
    const { gl, programInfo, positionBuffer } = initWebGL();
    if (gl && programInfo && positionBuffer) {
        drawCar(gl, programInfo, positionBuffer);
    }
})();
