// Vertex shader program
const vsSource = `
    attribute vec2 aVertexPosition;
    void main(void) {
        gl_Position = vec4(aVertexPosition, 0.0, 1.0);
    }
`;

// Fragment shader program
const fsSource = `
    precision mediump float;
    uniform vec4 uColor;
    void main(void) {
        gl_FragColor = uColor;
    }
`;

function initWebGL() {
    const canvas = document.getElementById('glCanvas');
    const gl = canvas.getContext('webgl');

    if (!gl) {
        alert('Não foi possível inicializar o WebGL. Seu navegador ou máquina pode não suportá-lo.');
        return null;
    }

    const shaderProgram = initShaderProgram(gl, vsSource, fsSource);

    const programInfo = {
        program: shaderProgram,
        attribLocations: {
            vertexPosition: gl.getAttribLocation(shaderProgram, 'aVertexPosition'),
        },
        uniformLocations: {
            color: gl.getUniformLocation(shaderProgram, 'uColor'),
        },
    };

    const positionBuffer = gl.createBuffer();

    return { gl, programInfo, positionBuffer };
}

function initShaderProgram(gl, vsSource, fsSource) {
    const vertexShader = loadShader(gl, gl.VERTEX_SHADER, vsSource);
    const fragmentShader = loadShader(gl, gl.FRAGMENT_SHADER, fsSource);

    const shaderProgram = gl.createProgram();
    gl.attachShader(shaderProgram, vertexShader);
    gl.attachShader(shaderProgram, fragmentShader);
    gl.linkProgram(shaderProgram);

    if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
        alert('Não foi possível inicializar o shader: ' + gl.getProgramInfoLog(shaderProgram));
        return null;
    }

    return shaderProgram;
}

function loadShader(gl, type, source) {
    const shader = gl.createShader(type);

    gl.shaderSource(shader, source);

    gl.compileShader(shader);

    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        alert('Erro ao compilar o shader: ' + gl.getShaderInfoLog(shader));
        gl.deleteShader(shader);
        return null;
    }

    return shader;
}

function drawFlower(gl, programInfo, positionBuffer) {
    gl.clearColor(0.9, 0.9, 0.9, 1.0); 
    gl.clear(gl.COLOR_BUFFER_BIT);

    gl.useProgram(programInfo.program);
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);

    gl.enableVertexAttribArray(programInfo.attribLocations.vertexPosition);
    gl.vertexAttribPointer(
        programInfo.attribLocations.vertexPosition,
        2,        
        gl.FLOAT, 
        false,    
        0,        
        0         
    );

    const segments = 50;

    // Desenha o caule
    const stemWidth = 0.02;
    const stemHeight = 0.4;
    const stemX = 0 - (stemWidth / 2);
    const stemY = -0.7;
    const stemColor = [0, 0.5, 0, 1]; // Verde escuro

    drawRectangle(gl, programInfo, stemX, stemY, stemWidth, stemHeight, stemColor);

    //desenha um losango no caule
    const losangoWidth = 0.14;
    const losangoHeight = 0.14;
    const losangoX = 0.06;
    const losangoY = -0.5;
    const losangoColor = [0, 0.5, 0, 1]; // Verde escuro
    drawLosango(gl, programInfo, losangoX, losangoY, losangoWidth, losangoHeight, losangoColor);

    // Desenha o miolo da flor
    const centerX = 0;
    const centerY = 0;
    const centerRadius = 0.1;
    const centerColor = [1, 1, 0, 1]; // Amarelo

    drawCircle(gl, programInfo, centerX, centerY, centerRadius, centerColor, segments);

    // Desenha as pétalas
    const petalRadius = 0.1;
    const petalColor = [1, 0, 1, 1]; // Vermelho
    const numPetals = 8;

    for (let i = 0; i < numPetals; i++) {
        const angle = (i / numPetals) * 2 * Math.PI;
        const petalX = centerX + (centerRadius + petalRadius) * Math.cos(angle);
        const petalY = centerY + (centerRadius + petalRadius) * Math.sin(angle);

        drawCircle(gl, programInfo, petalX, petalY, petalRadius, petalColor, segments);
    }
}

function drawCircle(gl, programInfo, centerX, centerY, radius, color, segments) {
    const vertices = [];
    vertices.push(centerX, centerY);
    for (let i = 0; i <= segments; i++) {
        const theta = (i / segments) * 2 * Math.PI;
        vertices.push(
            centerX + radius * Math.cos(theta),
            centerY + radius * Math.sin(theta)
        );
    }

    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    gl.uniform4fv(programInfo.uniformLocations.color, color);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, segments + 2);
}

function drawLosango(gl, programInfo, centerX, centerY, width, height, color) {
    const vertices = [
        centerX, centerY - height / 4, // Ponto superior
        centerX + width / 2, centerY, // Ponto direito
        centerX, centerY + height / 4, // Ponto inferior
        centerX - width / 2, centerY,
    ];

    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    gl.uniform4fv(programInfo.uniformLocations.color, color);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);
}

function drawRectangle(gl, programInfo, x, y, width, height, color) {
    const vertices = [
        x, y,
        x + width, y,
        x + width, y + height,
        x, y + height,
    ];

    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    gl.uniform4fv(programInfo.uniformLocations.color, color);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);
}

function drawTriangle(gl, programInfo, vertices, color) {
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    gl.uniform4fv(programInfo.uniformLocations.color, color);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
}

(function main() {
    const { gl, programInfo, positionBuffer } = initWebGL();
    if (gl && programInfo && positionBuffer) {
        drawFlower(gl, programInfo, positionBuffer);
    }
})();
