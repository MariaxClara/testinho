export default [
  'blog-using-vue-nuxt-markdown',
  'vuex-what-is-when-use-it',
  'design-and-code-skeletons-screens',
  'bacon-ipsum',
]