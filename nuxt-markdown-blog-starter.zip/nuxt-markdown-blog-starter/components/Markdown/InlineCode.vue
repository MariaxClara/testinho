<template>
  <code>
    <slot></slot>
  </code>
</template>