import Vue from 'vue'
import ImageResponsive from "~/components/Image.vue";

Vue.component('ImageResponsive', ImageResponsive)