<template>
  <div class="container">
    Se ha producido un error
  </div>
</template>