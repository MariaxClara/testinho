export default {
  credits: 'Open source template. Check the code at <a target="_blank" href="https://github.com/marinaaisa/nuxt-markdown-blog-starter" class="ani"><span>Github</span></a>. Project done by <a target="_blank" href="https://marinaaisa.com/" class="ani"><span>Marina Aisa</span></a>.'
}