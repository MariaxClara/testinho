export default {
  title: 'Marina Aísa - Product Designer and Front-End Developer',
  description: 'I’m a Product Designer (UI/UX) and Front-End Developer based in Barcelona.'
}
