import footer from './footer'
import indexPageHead from './index-page-head'

export default {
  changeLanguagePost: 'Artículo disponible en español',
  soonLanguagePost: 'Artículo disponible en español pronto',
  comeBack: 'Come back',
  indexPageHead: indexPageHead,
  posts: 'Posts',
  home: 'Home',
  footer: footer
}
