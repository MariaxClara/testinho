const vsSource = `
attribute vec2 aVertexPosition;
uniform mat4 uModelViewMatrix;
void main(void) {
    gl_Position = uModelViewMatrix * vec4(aVertexPosition, 0.0, 1.0);
}
`;

const fsSource = `
precision mediump float;
uniform vec4 uColor;
void main(void) {
    gl_FragColor = uColor;
}
`;

function initWebGL() {
const canvas = document.getElementById('glCanvas');
const gl = canvas.getContext('webgl');

if (!gl) {
    alert('WebGL não é suportado neste navegador.');
    return null;
}

const shaderProgram = initShaderProgram(gl, vsSource, fsSource);
const programInfo = {
    program: shaderProgram,
    attribLocations: {
        vertexPosition: gl.getAttribLocation(shaderProgram, 'aVertexPosition'),
    },
    uniformLocations: {
        modelViewMatrix: gl.getUniformLocation(shaderProgram, 'uModelViewMatrix'),
        color: gl.getUniformLocation(shaderProgram, 'uColor'),
    },
};

const positionBuffer = gl.createBuffer();
return { gl, programInfo, positionBuffer };
}

function initShaderProgram(gl, vsSource, fsSource) {
const vertexShader = loadShader(gl, gl.VERTEX_SHADER, vsSource);
const fragmentShader = loadShader(gl, gl.FRAGMENT_SHADER, fsSource);

const shaderProgram = gl.createProgram();
gl.attachShader(shaderProgram, vertexShader);
gl.attachShader(shaderProgram, fragmentShader);
gl.linkProgram(shaderProgram);

if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
    alert('Não foi possível inicializar o programa de shader.');
    return null;
}

return shaderProgram;
}

function loadShader(gl, type, source) {
const shader = gl.createShader(type);
gl.shaderSource(shader, source);
gl.compileShader(shader);

if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    alert('Erro ao compilar o shader.');
    gl.deleteShader(shader);
    return null;
}

return shader;
}

function drawScene(gl, programInfo, positionBuffer, time, viewport) {
gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
gl.useProgram(programInfo.program);

const squareVertices = [
    -0.5, -0.5,
     0.5, -0.5,
     0.5,  0.5,
    -0.5,  0.5,
];

gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(squareVertices), gl.STATIC_DRAW);
gl.vertexAttribPointer(programInfo.attribLocations.vertexPosition, 2, gl.FLOAT, false, 0, 0);
gl.enableVertexAttribArray(programInfo.attribLocations.vertexPosition);

gl.viewport(viewport.x, viewport.y, viewport.width, viewport.height);
gl.scissor(viewport.x, viewport.y, viewport.width, viewport.height);
gl.enable(gl.SCISSOR_TEST);

const rotation = viewport.rotationSpeed * time * 0.001;
const scale = viewport.scaleBase + viewport.scaleAmplitude * Math.abs(Math.sin(time * 0.002));
const modelViewMatrix = [
    Math.cos(rotation) * scale, -Math.sin(rotation) * scale, 0, 0,
    Math.sin(rotation) * scale,  Math.cos(rotation) * scale, 0, 0,
    0,                          0,                          1, 0,
    0,                          0,                          0, 1,
];

gl.uniformMatrix4fv(programInfo.uniformLocations.modelViewMatrix, false, modelViewMatrix);
gl.uniform4fv(programInfo.uniformLocations.color, viewport.color);

gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);

gl.disable(gl.SCISSOR_TEST);
}

function animate(gl, programInfo, positionBuffer) {
function render(time) {
    gl.clearColor(0.2, 0.2, 0.2, 1.0);
    gl.clear(gl.COLOR_BUFFER_BIT);

    const viewports = [
        { x: 0, y: 300, width: 200, height: 300, color: [1.0, 0.0, 0.0, 1.0], rotationSpeed: 0.0, scaleBase: 0.8, scaleAmplitude: 1.0},
        { x: 300, y: 300, width: 300, height: 300, color: [0.0, 1.0, 0.0, 1.0], rotationSpeed: 3.8, scaleBase: 0.6, scaleAmplitude: 0.3 },
        { x: -150, y: -50, width: 400, height: 400, color: [0.0, 0.0, 1.0, 1.0], rotationSpeed: 2.0, scaleBase: 0.7, scaleAmplitude: 0.1 },
        { x: 300, y: 0, width: 300, height: 300, color: [1.0, 1.0, 0.0, 1.0], rotationSpeed: 1.0, scaleBase: 0.9, scaleAmplitude: 0.2 },
    ];

    viewports.forEach((viewport) => {
        drawScene(gl, programInfo, positionBuffer, time, viewport);
    });

    requestAnimationFrame(render);
}

requestAnimationFrame(render);
}

(function main() {
const { gl, programInfo, positionBuffer } = initWebGL();
if (gl && programInfo && positionBuffer) {
    animate(gl, programInfo, positionBuffer);
}
})();
